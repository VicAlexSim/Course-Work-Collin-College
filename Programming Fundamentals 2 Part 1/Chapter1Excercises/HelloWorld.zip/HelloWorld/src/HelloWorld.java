/*
 * Program Description - Prints "Hello World" on screen
 * Written by Victor Sim
 * on 1/21/2022
 * JDK 17.0.2
 */

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World. "
                + "\nVictor Sim.");
    }
}
