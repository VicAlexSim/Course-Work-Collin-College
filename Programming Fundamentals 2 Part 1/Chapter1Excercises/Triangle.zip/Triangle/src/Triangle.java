/* This program will print a triangle shape.
 * Written by Victor Sim on 1/21/2022
 * JDK 17.0.2
 */

public class Triangle {
    public static void main(String[] args) {
        System.out.println("      *");
        System.out.println("     ***");
        System.out.println("    *****");
        System.out.println("   *******");
        System.out.println("  *********");
        System.out.println(" ***********");
    }
}
