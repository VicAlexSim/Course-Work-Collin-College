/**
 * Victor Sim
 * 5/14/22
 * JDK 17.0.2
 * This program will be the driver/main function/method for the Alien Game.
 */

package finalexam;

import java.util.ArrayList;

public class FinalExam {

    public static void main(String[] args) {
        ArrayList<>
        Alien[] array = new Alien[4];
        
        array[0] = new Alien(3);
        array[1] = new Alien(5);
        array[2] = new RattlesnakeAlien(10);
        array[3] = new Alien(0);
    }
    }
    
}
