/**
 * Victor Sim
 * 5/14/22
 * JDK 17.0.2
 * This program will be the Exception class for no damage for the Alien Game.
 */
package finalexam;

public class NoDamage {
    
}
