/**
 * Victor Sim
 * 6/29/22
 * JDK 17.0.2
 * Interface
 */
//Package statement
package shipdemo;

/**
 *
 * @author Owner
 */
public interface Displayable {
    void display();
}
