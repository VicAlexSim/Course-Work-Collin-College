public interface Displayable
{
   void display();
}